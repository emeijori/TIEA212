﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Markup;
using System.Diagnostics;

namespace Epilepsia
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void print_Click(object sender, RoutedEventArgs e)
        {
            PrintDialog pd = new PrintDialog();
            if (pd.ShowDialog() != true) return;

            FixedDocument document = new FixedDocument();
            document.DocumentPaginator.PageSize = new Size(pd.PrintableAreaWidth, pd.PrintableAreaHeight);

            FixedPage page1 = new FixedPage();
            page1.Width = document.DocumentPaginator.PageSize.Width;
            page1.Height = document.DocumentPaginator.PageSize.Height;

            StackPanel paneli = new StackPanel();
            paneli.Width = page1.Width;
            paneli.Height = page1.Height;
            paneli.Margin = new Thickness(46);
            page1.Children.Add(paneli);

            TextBlock page1Header = new TextBlock();
            page1Header.Text = "GKO";
            page1Header.FontSize = 40;
            page1Header.Margin = new Thickness(0, 0, 0, 20);
            paneli.Children.Add(page1Header);

            TextBlock page1Text = new TextBlock();
            page1Text.Text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent \n" +
            "volutpat nibh non metus congue in blandit erat volutpat. Sed ut ipsum \n " +
            "dolor. Aliquam tempor dapibus lectus, eu consequat metus pretium ut. \n" +
            "Phasellus molestie velit sed felis tristique quis condimentum neque \n" +
            "sagittis. Nunc mattis nulla vitae est tincidunt nec facilisis nibh \n" +
            "pretium. Nulla ut tincidunt felis. Donec lectus odio, dictum ac \n" +
            "condimentum sit amet, porta quis massa. Sed at quam cursus tellus mattis \n" +
            "ornare.";
            page1Text.FontSize = 16;
            paneli.Children.Add(page1Text);

            TextBlock page1Text1 = new TextBlock();
            page1Text1.Text = "Class aptent taciti sociosqu ad litora torquent per conubia nostra, per \n" +
                "inceptos himenaeos. Praesent sodales velit vel enim euismod non \n" +
                "pellentesque neque pulvinar. Quisque dui purus, fermentum id mattis ac, \n" +
                "pellentesque et neque. Integer vehicula enim et nunc bibendum tincidunt \n" +
            "in tincidunt urna. In vestibulum varius varius. Nullam venenatis, lectus \n" +
            "et suscipit suscipit, mi lorem hendrerit risus, vitae sagittis leo urna \n" +
            "et metus. Suspendisse elementum, lorem molestie tristique laoreet, nisi \n" +
            "libero mattis purus, ut eleifend orci nibh id diam. Nunc at odio sit \n" +
            "amet diam convallis tincidunt id non massa. Mauris non nisi ante, et \n" +
            "gravida mi. Phasellus tempor nisl sed metus egestas euismod. Ut non \n" +
            "pharetra risus. Curabitur consequat congue orci, sollicitudin \n" +
            "consectetur erat posuere vel. Quisque dictum ornare ipsum id accumsan.";
            page1Text1.FontSize = 16;
            page1Text1.Margin = new Thickness(0, 20, 0, 0);
            paneli.Children.Add(page1Text1);

            TextBlock page1Text2 = new TextBlock();
            page1Text2.Text = "Sed accumsan pharetra augue vitae elementum. Praesent sagittis volutpat \n" +
            "tortor, sed auctor lacus sodales nec. Vivamus sit amet massa sed ipsum \n" +
            "placerat pretium. Sed volutpat tincidunt bibendum. Class aptent taciti \n" +
            "sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. \n" +
            "Phasellus bibendum iaculis dolor, eu porta diam dapibus sed. Cras \n" +
            "tristique feugiat euismod. Quisque tincidunt malesuada mollis.";
            page1Text2.FontSize = 16;
            page1Text2.Margin = new Thickness(0, 20, 0, 0);
            paneli.Children.Add(page1Text2);

            TextBlock page1Text3 = new TextBlock();
            page1Text3.Text = "Etiam at sapien tempus tortor euismod convallis a sed sapien. Proin \n" +
            "rhoncus nunc sed dui semper lobortis. Sed pharetra ante in ante porta \n" +
            "vehicula. Aliquam nec sollicitudin metus. Fusce mattis imperdiet \n" +
            "porttitor. Fusce at cursus elit. Vestibulum ante ipsum primis in \n" +
            "faucibus orci luctus et ultrices posuere cubilia Curae; Pellentesque \n" +
            "facilisis ante a ante dictum rhoncus fringilla dui tincidunt. Morbi \n" +
            "pellentesque, turpis ac semper dapibus, risus arcu sagittis nulla, eget \n" +
            "volutpat nulla nisl eget elit. Aenean laoreet, sapien vel euismod \n" +
            "egestas, tellus tellus suscipit nibh, sed sollicitudin enim felis sit \n" +
            "amet nulla. Donec justo turpis, porttitor et viverra id, sagittis ut \n" +
            "ipsum. Fusce eu sagittis purus. Donec laoreet mi ac sapien aliquet \n" +
            "vulputate. Proin ac ipsum nec urna cursus laoreet. Mauris porta nunc sit \n" +
            "amet metus tincidunt blandit.";
            page1Text3.FontSize = 16;
            page1Text3.Margin = new Thickness(0, 20, 0, 0);
            paneli.Children.Add(page1Text3);

            PageContent page1Content = new PageContent();
            ((IAddChild)page1Content).AddChild(page1);
            document.Pages.Add(page1Content);


            pd.PrintDocument(document.DocumentPaginator, "FixedDocument");
        }
    }
}

