﻿namespace Canasta2
{
    partial class jakoKontrolli
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jako = new System.Windows.Forms.GroupBox();
            this.taulukkoTausta = new System.Windows.Forms.TableLayoutPanel();
            this.puolueLabel1 = new System.Windows.Forms.Label();
            this.puolueLabel2 = new System.Windows.Forms.Label();
            this.bonusLabel = new System.Windows.Forms.Label();
            this.korttiLabel = new System.Windows.Forms.Label();
            this.yhteensaLabel = new System.Windows.Forms.Label();
            this.bonusPisteKentta1 = new System.Windows.Forms.TextBox();
            this.bonusPisteKentta2 = new System.Windows.Forms.TextBox();
            this.korttiPisteKentta1 = new System.Windows.Forms.TextBox();
            this.korttiPisteKentta2 = new System.Windows.Forms.TextBox();
            this.yhteensaPisteKentta1 = new System.Windows.Forms.TextBox();
            this.yhteensaPisteKentta2 = new System.Windows.Forms.TextBox();
            this.jako.SuspendLayout();
            this.taulukkoTausta.SuspendLayout();
            this.SuspendLayout();
            // 
            // jako
            // 
            this.jako.Controls.Add(this.taulukkoTausta);
            this.jako.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jako.Location = new System.Drawing.Point(0, 0);
            this.jako.Name = "jako";
            this.jako.Size = new System.Drawing.Size(238, 121);
            this.jako.TabIndex = 3;
            this.jako.TabStop = false;
            this.jako.Text = "Jako";
            // 
            // taulukkoTausta
            // 
            this.taulukkoTausta.ColumnCount = 3;
            this.taulukkoTausta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 65F));
            this.taulukkoTausta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.taulukkoTausta.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.taulukkoTausta.Controls.Add(this.puolueLabel1, 1, 0);
            this.taulukkoTausta.Controls.Add(this.puolueLabel2, 2, 0);
            this.taulukkoTausta.Controls.Add(this.bonusLabel, 0, 1);
            this.taulukkoTausta.Controls.Add(this.korttiLabel, 0, 2);
            this.taulukkoTausta.Controls.Add(this.yhteensaLabel, 0, 3);
            this.taulukkoTausta.Controls.Add(this.bonusPisteKentta1, 1, 1);
            this.taulukkoTausta.Controls.Add(this.bonusPisteKentta2, 2, 1);
            this.taulukkoTausta.Controls.Add(this.korttiPisteKentta1, 1, 2);
            this.taulukkoTausta.Controls.Add(this.korttiPisteKentta2, 2, 2);
            this.taulukkoTausta.Controls.Add(this.yhteensaPisteKentta1, 1, 3);
            this.taulukkoTausta.Controls.Add(this.yhteensaPisteKentta2, 2, 3);
            this.taulukkoTausta.Dock = System.Windows.Forms.DockStyle.Fill;
            this.taulukkoTausta.Location = new System.Drawing.Point(3, 16);
            this.taulukkoTausta.Name = "taulukkoTausta";
            this.taulukkoTausta.RowCount = 4;
            this.taulukkoTausta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.taulukkoTausta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.taulukkoTausta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.taulukkoTausta.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.taulukkoTausta.Size = new System.Drawing.Size(232, 102);
            this.taulukkoTausta.TabIndex = 0;
            // 
            // puolueLabel1
            // 
            this.puolueLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.puolueLabel1.AutoSize = true;
            this.puolueLabel1.Location = new System.Drawing.Point(82, 3);
            this.puolueLabel1.Name = "puolueLabel1";
            this.puolueLabel1.Size = new System.Drawing.Size(49, 13);
            this.puolueLabel1.TabIndex = 0;
            this.puolueLabel1.Text = "Puolue 1";
            // 
            // puolueLabel2
            // 
            this.puolueLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.puolueLabel2.AutoSize = true;
            this.puolueLabel2.Location = new System.Drawing.Point(165, 3);
            this.puolueLabel2.Name = "puolueLabel2";
            this.puolueLabel2.Size = new System.Drawing.Size(49, 13);
            this.puolueLabel2.TabIndex = 1;
            this.puolueLabel2.Text = "Puolue 2";
            // 
            // bonusLabel
            // 
            this.bonusLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bonusLabel.AutoSize = true;
            this.bonusLabel.Location = new System.Drawing.Point(14, 27);
            this.bonusLabel.Name = "bonusLabel";
            this.bonusLabel.Size = new System.Drawing.Size(37, 13);
            this.bonusLabel.TabIndex = 2;
            this.bonusLabel.Text = "Bonus";
            // 
            // korttiLabel
            // 
            this.korttiLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.korttiLabel.AutoSize = true;
            this.korttiLabel.Location = new System.Drawing.Point(17, 54);
            this.korttiLabel.Name = "korttiLabel";
            this.korttiLabel.Size = new System.Drawing.Size(31, 13);
            this.korttiLabel.TabIndex = 3;
            this.korttiLabel.Text = "Kortti";
            // 
            // yhteensaLabel
            // 
            this.yhteensaLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.yhteensaLabel.AutoSize = true;
            this.yhteensaLabel.Location = new System.Drawing.Point(6, 81);
            this.yhteensaLabel.Name = "yhteensaLabel";
            this.yhteensaLabel.Size = new System.Drawing.Size(52, 13);
            this.yhteensaLabel.TabIndex = 4;
            this.yhteensaLabel.Text = "Yhteensä";
            // 
            // bonusPisteKentta1
            // 
            this.bonusPisteKentta1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bonusPisteKentta1.Location = new System.Drawing.Point(68, 23);
            this.bonusPisteKentta1.Name = "bonusPisteKentta1";
            this.bonusPisteKentta1.Size = new System.Drawing.Size(77, 20);
            this.bonusPisteKentta1.TabIndex = 5;
            this.bonusPisteKentta1.Tag = "bonus";
            this.bonusPisteKentta1.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // bonusPisteKentta2
            // 
            this.bonusPisteKentta2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bonusPisteKentta2.Location = new System.Drawing.Point(151, 23);
            this.bonusPisteKentta2.Name = "bonusPisteKentta2";
            this.bonusPisteKentta2.Size = new System.Drawing.Size(78, 20);
            this.bonusPisteKentta2.TabIndex = 6;
            this.bonusPisteKentta2.Tag = "bonus";
            this.bonusPisteKentta2.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // korttiPisteKentta1
            // 
            this.korttiPisteKentta1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.korttiPisteKentta1.Location = new System.Drawing.Point(68, 50);
            this.korttiPisteKentta1.Name = "korttiPisteKentta1";
            this.korttiPisteKentta1.Size = new System.Drawing.Size(77, 20);
            this.korttiPisteKentta1.TabIndex = 7;
            this.korttiPisteKentta1.Tag = "kortti";
            this.korttiPisteKentta1.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // korttiPisteKentta2
            // 
            this.korttiPisteKentta2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.korttiPisteKentta2.Location = new System.Drawing.Point(151, 50);
            this.korttiPisteKentta2.Name = "korttiPisteKentta2";
            this.korttiPisteKentta2.Size = new System.Drawing.Size(78, 20);
            this.korttiPisteKentta2.TabIndex = 8;
            this.korttiPisteKentta2.Tag = "kortti";
            this.korttiPisteKentta2.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // yhteensaPisteKentta1
            // 
            this.yhteensaPisteKentta1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.yhteensaPisteKentta1.Location = new System.Drawing.Point(68, 78);
            this.yhteensaPisteKentta1.Name = "yhteensaPisteKentta1";
            this.yhteensaPisteKentta1.ReadOnly = true;
            this.yhteensaPisteKentta1.Size = new System.Drawing.Size(77, 20);
            this.yhteensaPisteKentta1.TabIndex = 9;
            this.yhteensaPisteKentta1.Tag = "yhteensa";
            this.yhteensaPisteKentta1.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // yhteensaPisteKentta2
            // 
            this.yhteensaPisteKentta2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.yhteensaPisteKentta2.Location = new System.Drawing.Point(151, 78);
            this.yhteensaPisteKentta2.Name = "yhteensaPisteKentta2";
            this.yhteensaPisteKentta2.ReadOnly = true;
            this.yhteensaPisteKentta2.Size = new System.Drawing.Size(78, 20);
            this.yhteensaPisteKentta2.TabIndex = 10;
            this.yhteensaPisteKentta2.Tag = "yhteensa";
            this.yhteensaPisteKentta2.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            // 
            // jakoKontrolli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.jako);
            this.Name = "jakoKontrolli";
            this.Size = new System.Drawing.Size(238, 121);
            this.jako.ResumeLayout(false);
            this.taulukkoTausta.ResumeLayout(false);
            this.taulukkoTausta.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox jako;
        private System.Windows.Forms.TableLayoutPanel taulukkoTausta;
        private System.Windows.Forms.Label puolueLabel1;
        private System.Windows.Forms.Label puolueLabel2;
        private System.Windows.Forms.Label bonusLabel;
        private System.Windows.Forms.Label korttiLabel;
        private System.Windows.Forms.Label yhteensaLabel;
        private System.Windows.Forms.TextBox bonusPisteKentta1;
        private System.Windows.Forms.TextBox bonusPisteKentta2;
        private System.Windows.Forms.TextBox korttiPisteKentta1;
        private System.Windows.Forms.TextBox korttiPisteKentta2;
        private System.Windows.Forms.TextBox yhteensaPisteKentta1;
        private System.Windows.Forms.TextBox yhteensaPisteKentta2;

    }
}
