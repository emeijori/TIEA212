﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VT6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Point startPoint = new Point(0, 0);

        public MainWindow()
        {
            InitializeComponent();
        }

        private void labelKaikki_MouseMove(object sender, MouseEventArgs e)
        {
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance)
            {
                DataObject dragData = new DataObject(DataFormats.Text, ((Label)sender).Content);
                DragDrop.DoDragDrop((Label)sender, dragData, DragDropEffects.Move);
            }
        }

        private void labelKaikki_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            startPoint = e.GetPosition(null);
        }

        private void Target_Drop(object sender, DragEventArgs e)
        {
            Label labelTarget = (Label)sender;

            Score.Content = int.Parse(Score.Content.ToString()) + int.Parse(e.Data.GetData(DataFormats.Text).ToString()) * int.Parse(labelTarget.Content.ToString());


        }
    }

    public static class DragNDropBehaviour
    {

        private static void UserControl_Drop(object sender, DragEventArgs e)
        {
            //Label labelSource = (Label)e.Data.GetData();
            Label labelTarget = (Label)sender;

            labelTarget.Content = int.Parse(e.Data.GetData(DataFormats.Text).ToString()) * int.Parse(labelTarget.Content.ToString());
        }

        public static bool GetDragNDropEnabled(DependencyObject obj)
        {
            return (bool)obj.GetValue(DragNDropEnabledProperty);
        }

        public static void SetDragNDropEnabled(DependencyObject obj, bool value)
        {
            obj.SetValue(DragNDropEnabledProperty, value);
        }

        public static readonly DependencyProperty DragNDropEnabledProperty =
         DependencyProperty.RegisterAttached("DragNDrop",
         typeof(bool), typeof(DragNDropBehaviour),
         new UIPropertyMetadata(false, OnDragNDropEnabledChanged));

        private static void OnDragNDropEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            Label label = (Label)sender;
            if ((bool)e.NewValue)
            {
                label.Drop += new DragEventHandler(UserControl_Drop);
            }
            else
            {
                label.Drop -= new DragEventHandler(UserControl_Drop);
            }
        }
    }
}