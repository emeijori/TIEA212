﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Harjoitustyo
{
    /// <summary>
    /// Interaction logic for Options.xaml
    /// Ei käytössä
    /// </summary>
    public partial class Options : Window
    {
        public Options()
        {
            InitializeComponent();
        }

        private void doneButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void boardSize1_Checked(object sender, RoutedEventArgs e)
        {
            SetValue(MainWindow.gameAreaSizeProperty, 7);
        }

        private void boardSize2_Checked(object sender, RoutedEventArgs e)
        {
            SetValue(MainWindow.gameAreaSizeProperty, 8);
        }

        private void optionWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (int.Parse(GetValue(MainWindow.gameAreaSizeProperty).ToString()) == 8)
            {
                boardSize1.IsChecked = false;
                boardSize2.IsChecked = true;
            }
            else if (int.Parse(GetValue(MainWindow.gameAreaSizeProperty).ToString()) == 7)
            {
                boardSize2.IsChecked = false;
                boardSize1.IsChecked = true;
            }
        }
    }
}
