﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Harjoitustyo
{
    /// <summary>
    /// Interaction logic for about.xaml, About window
    /// </summary>
    public partial class About : Window
    {
        public About()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Closes the about window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeAboutButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
