﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Harjoitustyo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml, pääikkuna
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Suljetaan pääikkuna ja samalla koko ohjelma
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Näytetään ohjelman tiedot
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void about_Click(object sender, RoutedEventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }

        // Ei käytössä
        private void optionsButton_Click(object sender, RoutedEventArgs e)
        {
            Options option = new Options();
            option.ShowDialog();
        }

        /// <summary>
        /// Aloitetaan (uusi)peli jolloin avataan peliikkuna
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newGameBut_Click(object sender, RoutedEventArgs e)
        {
            GameWindow newGame = new GameWindow();
            newGame.ShowDialog();
        }

        // Ei käytössä
        public static readonly DependencyProperty gameAreaSizeProperty =
    DependencyProperty.Register("gameAreaSize", typeof(int), typeof(MainWindow), new PropertyMetadata(8));

        public bool gameAreaSize
        {
            get { return (bool)GetValue(gameAreaSizeProperty); }
            set { SetValue(gameAreaSizeProperty, value); }
        }

        /// <summary>
        /// Näytetään ohjelman toiminnallisuuteen liittyvää neuvoa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            GameHelp helpperinos = new GameHelp();
            helpperinos.ShowDialog();
        }
    }
}
