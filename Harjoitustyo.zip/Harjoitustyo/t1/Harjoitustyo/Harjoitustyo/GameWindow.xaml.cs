﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Harjoitustyo
{
    /// <summary>
    /// Interaction logic for PeliIkkuna.xaml
    /// </summary>
    public partial class GameWindow : Window
    {
        /// <summary>
        /// Avaa peliikkunan ja luo sen sisälle pelialueenappuloineen
        /// </summary>
        public GameWindow()
        {
            InitializeComponent();

            // Luodaan uusi pelikenttä ja asetetaan se ruudukkoon
            GameArea playField = new GameArea();
            gameWindow.windowGrid.Children.Add(playField);
            Grid.SetRow(playField, 2);
            Grid.SetColumn(playField, 1);
        }

        // Ei käytössä
        private void option_Click(object sender, RoutedEventArgs e)
        {
            Options option = new Options();
            option.boardSize1.IsEnabled = false;
            option.boardSize2.IsEnabled = false;
            option.ShowDialog();
        }

        /// <summary>
        /// Poistutaan ikkunasta
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Näytetään ohjelman tiedot
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void about_Click(object sender, RoutedEventArgs e)
        {
            About about = new About();
            about.ShowDialog();
        }

        /// <summary>
        /// Näytetään pelin säännöt
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void instruction_Click(object sender, RoutedEventArgs e)
        {
            Instructions instruction = new Instructions();
            instruction.ShowDialog();
        }

        /// <summary>
        /// Aloitetaan uusipeli
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newGameItem_Click(object sender, RoutedEventArgs e)
        {
            gameWindow.windowGrid.Children.RemoveAt(windowGrid.Children.Count - 1);
            GameArea playField = new GameArea();
            gameWindow.windowGrid.Children.Add(playField);
            Grid.SetRow(playField, 2);
            Grid.SetColumn(playField, 1);

            newGameStartedWindow started = new newGameStartedWindow();
            started.ShowDialog();
        }
    }
}
