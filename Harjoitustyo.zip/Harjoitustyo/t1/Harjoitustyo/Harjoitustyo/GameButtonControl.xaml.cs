﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Harjoitustyo
{
    /// <summary>
    /// Interaction logic for GameButtonControl.xaml, Nappulat jota pelissä käytetään
    /// </summary>
    public partial class GameButtonControl : UserControl
    {
        // Katso property alla
        int x = 0;
        int y = 0;

        public GameButtonControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Nappuloiden kordinaatit pelikentällä
        /// </summary>
        public int positionX
        {
            get { return x; }
            set { x = value; }
        }

        public int positionY
        {
            get { return y; }
            set { y = value; }
        }
    }
}
