﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Harjoitustyo
{
    /// <summary>
    /// Interaction logic for gameArea.xaml, Pelikenttä
    /// </summary>
    public partial class GameArea : UserControl
    {
        //Pelilogiikaan liittyviä
        bool player1Turn = true;
        bool buttonChoosen = false;
        bool redButtonChoosen = false;
        bool blueButtonChoosen = false;
        bool gameWon = false;

        SolidColorBrush choosenColor;
        int choosenButtonX, choosenButtonY;
        int areaSize = 8;

        SolidColorBrush redColor = new SolidColorBrush(Colors.Red);
        SolidColorBrush blueColor = new SolidColorBrush(Colors.Blue);
        SolidColorBrush greenColor = new SolidColorBrush(Colors.Green);
        SolidColorBrush yellowColor = new SolidColorBrush(Colors.Yellow);

        // Pelinappulakontrolleja
        GameButtonControl[,] position;

         /// <summary>
         /// Kutsuu pelikentän luovan aliohjelman ja luo samalla taulukon peliobjekteille
         /// </summary>
        public GameArea()
        {
            InitializeComponent();

            // Luodaan uusi taulukko pelinappuloille ja samalla luodaan pelialuenappuloineen
            position = new GameButtonControl[areaSize, areaSize];
            createGameBoard(areaSize);
        }

        /// <summary>
        /// Luo pelikentän objekteineen
        /// </summary>
        /// <param name="areaSize1">Kentänkoko</param>
        public void createGameBoard(int areaSize1)
        {

            // Jaetaan kentä ruudukkoon
            RowDefinitionCollection[] rows = new RowDefinitionCollection[areaSize1];
            ColumnDefinitionCollection[] columns = new ColumnDefinitionCollection[areaSize1];

            GridLengthConverter gridLengthConverter = new GridLengthConverter();

            // Täytetään ruudukko taustalla
            for (int i = 0; i < areaSize1; i++)
            {
                RowDefinition row = new RowDefinition();
                row.Name = "row" + i.ToString(); ;
                row.Height = (GridLength)gridLengthConverter.ConvertFrom("*");
                gameGrid.RowDefinitions.Add(row);

                ColumnDefinition column = new ColumnDefinition();
                column.Name = "column" + i.ToString(); ;
                column.Width = (GridLength)gridLengthConverter.ConvertFrom("*");
                gameGrid.ColumnDefinitions.Add(column);
            }

            // Lisätään ruudukkoon nappulat
            for (int i = 0; i < areaSize1; i++)
            {
                SolidColorBrush brushBlack = new SolidColorBrush(Colors.Black);
                SolidColorBrush brushWhite = new SolidColorBrush(Colors.White);

                for (int j = 0; j < areaSize1; j++)
                {
                    // Maalataan tausta joko valkoiseksi tai mustaksi, niin että saadaan ruudukko
                    Rectangle backGroundColor = new Rectangle();
                    if ((j + i) % 2 == 0) backGroundColor.Fill = brushBlack;
                    else backGroundColor.Fill = brushWhite;

                    // Luodaan pelinappulat
                    GameButtonControl gameButton = new GameButtonControl();
                    gameButton.IsEnabled = true;
                    gameButton.Visibility = System.Windows.Visibility.Visible;
                    gameButton.stylizedButton.Background = yellowColor;
                    gameButton.Opacity = 0.0;
                    gameButton.stylizedButton.Click += new RoutedEventHandler(stylizedButton_Click);

                    // Luodaan pelaaja 2 aloitus nappulat
                    if (i == 0 || i == 1)
                    {
                        gameButton.Opacity = 100.0;
                        gameButton.stylizedButton.Background = blueColor;
                    }

                    // Luodaan pelaaja 1 aloitus nappulat
                    if (i == areaSize1 - 1 || i == areaSize1 - 2)
                    {
                        gameButton.Opacity = 100.0;
                        gameButton.stylizedButton.Background = redColor;
                    }

                    // Otetaan paikoitus muistiin
                    position[i, j] = gameButton;
                    gameButton.positionX = j;
                    gameButton.positionY = i;

                    // Lisätään tausta väri ja nappulat
                    gameGrid.Children.Add(backGroundColor);
                    Grid.SetColumn(backGroundColor, j);
                    Grid.SetRow(backGroundColor, i);

                    gameGrid.Children.Add(gameButton);
                    Grid.SetColumn(gameButton, j);
                    Grid.SetRow(gameButton, i);
                }
            }
        }

        /// <summary>
        /// Pelilogiikka kokonaisuudessaan
        /// </summary>
        /// <param name="sender">Nappi jota painettiin</param>
        /// <param name="e"></param>
        private void stylizedButton_Click(object sender, RoutedEventArgs e)
        {

            // Määritellään mitä kontrollia ollaan käsittelemässä
            Button sender0 = (Button)sender;
            Grid sender1 = (Grid)sender0.Parent;
            GameButtonControl sender2 = (GameButtonControl)sender1.Parent;
            int x = sender2.positionX;
            int y = sender2.positionY;

            // Jos peli on jo voitettu ei tehdä mitään
            if (gameWon) return;

            // Jos jokin nappula on valittuna mennään kattomaan mitä sille tehdään
            if (buttonChoosen)
            {
                // Poistetaan nappulan valinta
                if (sender0.Background == greenColor)
                {
                    sender0.Background = choosenColor;
                    buttonChoosen = false;
                    return;
                }

                // Pelaaja kakkosen valinnat
                if (blueButtonChoosen && sender2.positionY == choosenButtonY + 1)
                {
                    // Jos yritetään syödä nappulaa
                    if (sender0.Background == redColor)
                    {
                        if (choosenButtonX == sender2.positionX - 1 || choosenButtonX == sender2.positionX + 1)
                        {
                            sender0.Background = blueColor;
                            position[choosenButtonY, choosenButtonX].Opacity = 0.0;
                            position[choosenButtonY, choosenButtonX].stylizedButton.Background = yellowColor;

                            // Voitettiinko peli
                            if (sender2.positionY == areaSize - 1)
                            {
                                sender0.Background = yellowColor;
                                gameWon = true;
                                return;
                            }

                            blueButtonChoosen = false;
                            buttonChoosen = false;
                            player1Turn = true;
                        }
                    }

                    // Jos yritetään siirtää nappulaa tyhjään ruutuun
                    if (sender0.Background == yellowColor)
                    {
                        if (choosenButtonX == sender2.positionX - 1 || choosenButtonX == sender2.positionX + 1 || choosenButtonX == sender2.positionX)
                        {
                            sender0.Background = blueColor;
                            sender2.Opacity = 100.0;
                            position[choosenButtonY, choosenButtonX].Opacity = 0.0;
                            position[choosenButtonY, choosenButtonX].stylizedButton.Background = yellowColor;

                            // Voitettiinko peli
                            if (sender2.positionY == areaSize - 1)
                            {
                                sender0.Background = yellowColor;
                                gameWon = true;
                                return;
                            }

                            blueButtonChoosen = false;
                            buttonChoosen = false;
                            player1Turn = true;
                        }
                    }
                }

                // Ykkös pelaajan mahdolliset siirrot
                if (redButtonChoosen && sender2.positionY == choosenButtonY - 1)
                {
                    //Jos yritetään syödä nappulaa
                    if (sender0.Background == blueColor)
                    {
                        if (choosenButtonX == sender2.positionX - 1 || choosenButtonX == sender2.positionX + 1)
                        {
                            sender0.Background = redColor;
                            position[choosenButtonY, choosenButtonX].Opacity = 0.0;
                            position[choosenButtonY, choosenButtonX].stylizedButton.Background = yellowColor;

                            // Voitettiinko peli
                            if (sender2.positionY == 0)
                            {
                                sender0.Background = yellowColor;
                                gameWon = true;
                                return;
                            }

                            redButtonChoosen = false;
                            buttonChoosen = false;
                            player1Turn = false;
                            return;
                        }
                    }

                    // Yritetään siirtyä tyhjään tilaan
                    if (sender0.Background == yellowColor)
                    {
                        if (choosenButtonX == sender2.positionX - 1 || choosenButtonX == sender2.positionX + 1 || choosenButtonX == sender2.positionX)
                        {
                            sender0.Background = redColor;
                            sender2.Opacity = 100.0;
                            position[choosenButtonY, choosenButtonX].Opacity = 0.0;
                            position[choosenButtonY, choosenButtonX].stylizedButton.Background = yellowColor;

                            // Voitettiinko peli
                            if (sender2.positionY == 0)
                            {
                                sender0.Background = yellowColor;
                                gameWon = true;
                                return;
                            }

                            redButtonChoosen = false;
                            buttonChoosen = false;
                            player1Turn = false;
                            return;
                        }
                    }
                }
            }

            // Pelaaja 1 vuoro ja nappulaa ei ole valittu
            if (player1Turn && sender0.Background == redColor && buttonChoosen == false)
            {
                sender0.Background = greenColor;
                buttonChoosen = true;
                redButtonChoosen = true;
                choosenButtonX = sender2.positionX;
                choosenButtonY = sender2.positionY;
                choosenColor = redColor;
                return;
            }

            // Pelaaja 2 vuoro ja nappulaa ei ole valittu
            if (player1Turn == false && sender0.Background == blueColor && buttonChoosen == false)
            {
                sender0.Background = greenColor;
                buttonChoosen = true;
                blueButtonChoosen = true;
                choosenButtonX = sender2.positionX;
                choosenButtonY = sender2.positionY;
                choosenColor = blueColor;
                return;
            }
        }
    }
}
