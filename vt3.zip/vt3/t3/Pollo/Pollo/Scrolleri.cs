﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Pollo
{
    public partial class Scrolleri : UserControl
    {
        string teksti = "GKO";
        float tekstinX, tekstinY, nopeusHori = -1, nopeusVert = 1, fontinKoko = 12F, tekstinLiikkumisNopeus = 1;
        Font fontti;

        public Scrolleri()
        {
            InitializeComponent();
            rullaavaTeksti = "GKO";
            fontti = new Font("TimesNewRoman", fonttiKoko);
            ScrollerinTimer.Start();
            tekstinX = this.Right;
            tekstinY = this.Top / 2;
        }

        public float tekstinNopeus
        {
            get { return tekstinLiikkumisNopeus; }

            set
            {
                tekstinLiikkumisNopeus = value;
                nopeusHori = -tekstinLiikkumisNopeus;
                nopeusVert = tekstinLiikkumisNopeus;
            }
        }

        public string rullaavaTeksti
        {
            get
            {
                return teksti;
            }

            set
            {
                teksti = value;
            }

        }

        public float fonttiKoko
        {
            get
            {
                return fontinKoko;
            }

            set
            {
                fontinKoko = value;
                fontti = new Font("TimesNewRoman", fonttiKoko);
            }

        }

        private void TekstiLiikkuu()
        {
            tekstinX += nopeusHori;
            tekstinY += nopeusVert;

            if (tekstinY < 0)
            {
                nopeusVert = -nopeusHori;
            }

            if (tekstinY > this.Height - fontinKoko)
            {
                nopeusVert = nopeusHori;
            }

            if (tekstinX < this.Left - teksti.Length * fontinKoko)
            {
                tekstinX = this.Right;
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.DrawString(teksti, fontti, Brushes.White, tekstinX, tekstinY);
        }

        private void ScrollerinTimer_Tick(object sender, EventArgs e)
        {
            TekstiLiikkuu();
            Invalidate();
        }
    }
}
