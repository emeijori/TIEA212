﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Pollo
{
    public partial class HorizontalBar : UserControl
    {
        Color farg1 = Color.OrangeRed, farg2 = Color.RosyBrown;

        public HorizontalBar()
        {
            InitializeComponent();
        }

        public Color vari1
        {
            get { return farg1; }
            set { farg1 = value; }
        }

        public Color vari2
        {
            get { return farg2; }
            set { farg2 = value; }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, farg1, farg2, 90F))
            {
                e.Graphics.FillRectangle(brush, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height / 2);
            }
            using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, farg2, farg1, 90F))
            {
                e.Graphics.FillRectangle(brush, 0, this.ClientRectangle.Height / 2, this.ClientRectangle.Width, this.ClientRectangle.Height);
            }
        }
    }
}
