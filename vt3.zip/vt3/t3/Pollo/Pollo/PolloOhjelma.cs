﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace Pollo
{
    public partial class PolloIkkuna : Form
    {
        Bitmap polloKuva = new Bitmap(Image.FromFile("owl.png")), kuva;
        int paikka = 100, nopeus = 2, suunta = 2, pollonKoko = 3;

        public PolloIkkuna()
        {
            InitializeComponent();
            PaaOhjelmaTimer.Start();
            PiirraPollo();
        }

        private void PolloLiikkuu()
        {
            paikka += nopeus;
            if (paikka > this.ClientSize.Width - (kuva.Width*1.5))
            {
                nopeus = -suunta;
            }
            
            if (paikka < (kuva.Width/2))
            {
                nopeus = suunta;
            }
        }

        private void PiirraPollo()
        {
            Bitmap uusi = new Bitmap(polloKuva, ClientSize.Width/pollonKoko, ClientSize.Height/pollonKoko);
            Graphics canvas = this.CreateGraphics();
            canvas.DrawImage(uusi, 0, 0);
            kuva = uusi;

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics canvas = e.Graphics;
            canvas.DrawImage(kuva, paikka, ClientSize.Height/2-kuva.Height/2);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color color1 = Color.DarkBlue;
            Color color2 = Color.White;

            using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, color1, color2, 90F))
            {
                e.Graphics.FillRectangle(brush, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height / 2);
            }
            using (LinearGradientBrush brush = new LinearGradientBrush(this.ClientRectangle, color2, color1, 90F))
            {
                e.Graphics.FillRectangle(brush, 0, this.ClientRectangle.Height / 2, this.ClientRectangle.Width, this.ClientRectangle.Height);
            }

        }

        private void PaaOhjelmaTimer_Tick(object sender, EventArgs e)
        {
            PolloLiikkuu();
            this.Invalidate();
        }

        private void PolloIkkuna_Resize(object sender, EventArgs e)
        {
            kuva = new Bitmap(polloKuva, ClientSize.Width / pollonKoko, ClientSize.Height / pollonKoko);
            Invalidate();
        }
    }
}
