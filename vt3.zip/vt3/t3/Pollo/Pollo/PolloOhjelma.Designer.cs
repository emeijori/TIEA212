﻿namespace Pollo
{
    partial class PolloIkkuna
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PaaOhjelmaTimer = new System.Windows.Forms.Timer(this.components);
            this.scrolleri1 = new Pollo.Scrolleri();
            this.SuspendLayout();
            // 
            // PaaOhjelmaTimer
            // 
            this.PaaOhjelmaTimer.Interval = 16;
            this.PaaOhjelmaTimer.Tick += new System.EventHandler(this.PaaOhjelmaTimer_Tick);
            // 
            // scrolleri1
            // 
            this.scrolleri1.BackColor = System.Drawing.Color.Black;
            this.scrolleri1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.scrolleri1.fonttiKoko = 12F;
            this.scrolleri1.ForeColor = System.Drawing.Color.White;
            this.scrolleri1.Location = new System.Drawing.Point(0, 204);
            this.scrolleri1.Name = "scrolleri1";
            this.scrolleri1.rullaavaTeksti = "Graafisten Käyttöliittymien Ohjelmointi";
            this.scrolleri1.Size = new System.Drawing.Size(284, 57);
            this.scrolleri1.TabIndex = 0;
            this.scrolleri1.tekstinNopeus = 1F;
            // 
            // PolloIkkuna
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.scrolleri1);
            this.DoubleBuffered = true;
            this.Name = "PolloIkkuna";
            this.Text = "Pöllö";
            this.Resize += new System.EventHandler(this.PolloIkkuna_Resize);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer PaaOhjelmaTimer;
        private Scrolleri scrolleri1;
    }
}

